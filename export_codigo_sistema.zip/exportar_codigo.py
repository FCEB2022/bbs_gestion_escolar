import os, zipfile

EXCLUDE_EXT = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.txt', '.sql', '.pyc'}
EXCLUDE_DIRS = {'.venv', 'venv', 'env', '__pycache__', '.git', 'instance'}
INCLUDE_EXT = {'.py', '.html', '.css', '.js'}

OUTPUT_FILE = "export_codigo_sistema.zip"

def debe_incluir(ruta):
    base = os.path.basename(ruta)
    if base.startswith('.') or base == '.env':
        return False
    ext = os.path.splitext(ruta)[1].lower()
    if ext in EXCLUDE_EXT:
        return False
    return ext in INCLUDE_EXT

def exportar_codigo():
    with zipfile.ZipFile(OUTPUT_FILE, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for carpeta, subdirs, archivos in os.walk('.'):
            subdirs[:] = [d for d in subdirs if d not in EXCLUDE_DIRS]
            for archivo in archivos:
                ruta = os.path.join(carpeta, archivo)
                if debe_incluir(ruta):
                    zipf.write(ruta, ruta)
    print(f"✅ Exportación completada: {OUTPUT_FILE}")

if __name__ == "__main__":
    exportar_codigo()
