from flask import render_template
from flask_login import login_required
from . import bp

@bp.route("/")
@login_required
def index():
    # aquí luego se agregará lógica de estadísticas reales
    return render_template("estadisticas/index.html", title="Estadísticas")
