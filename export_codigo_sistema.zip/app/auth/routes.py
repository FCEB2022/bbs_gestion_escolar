from flask import render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, current_user
from app.extensions import db
from app.models_shared import registrar_actividad
from app.usuarios.models import Usuario
from datetime import datetime
from app import app


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        user = Usuario.query.filter_by(username=username).first()

        if user and user.check_password(password) and user.activo:
            login_user(user)
            user.ultimo_login = datetime.utcnow()
            user.sesion_activa = True
            db.session.commit()
            registrar_actividad(user, "Inicio de sesión", request.remote_addr, request.user_agent.string)
            flash("Inicio de sesión exitoso.", "success")
            return redirect(url_for("dashboard.index"))
        else:
            registrar_actividad(user, "Intento fallido de inicio de sesión", request.remote_addr)
            flash("Credenciales inválidas o usuario inactivo.", "error")
    return render_template("auth/login.html")


@app.route("/logout")
def logout():
    if current_user.is_authenticated:
        registrar_actividad(current_user, "Cierre de sesión", request.remote_addr, request.user_agent.string)
        current_user.sesion_activa = False
        db.session.commit()
        logout_user()
        flash("Sesión cerrada correctamente.", "info")
    return redirect(url_for("auth.login"))
