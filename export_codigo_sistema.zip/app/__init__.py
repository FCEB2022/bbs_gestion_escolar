from flask import Flask
from .config import Config
from .extensions import db, migrate, login_manager
from .models import User


def create_app():
    from .seed import seed_datos_iniciales
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(Config)

    # ---- Inicializar extensiones ----
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)

    # Configurar LoginManager
    login_manager.login_view = "auth.login"
    login_manager.login_message_category = "info"

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    # ---- Registrar Blueprints ----
    from .core import bp as core_bp
    from .auth import bp as auth_bp
    from .usuarios import bp as usuarios_bp
    from .documentos import bp as documentos_bp
    from .cursos import bp as cursos_bp
    from .matriculas import bp as matriculas_bp
    from .pagos import bp as pagos_bp
    from .actas_expedientes import bp as actas_bp
    from .validaciones import bp as validaciones_bp
    from .proyectos import bp as proyectos_bp
    from .estadisticas import bp as estadisticas_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(core_bp)
    app.register_blueprint(usuarios_bp, url_prefix="/usuarios")
    app.register_blueprint(documentos_bp, url_prefix="/documentos")
    app.register_blueprint(cursos_bp, url_prefix="/cursos")
    app.register_blueprint(matriculas_bp, url_prefix="/matriculas")
    app.register_blueprint(pagos_bp, url_prefix="/pagos")
    app.register_blueprint(actas_bp, url_prefix="/actas-expedientes")
    app.register_blueprint(validaciones_bp, url_prefix="/validaciones")
    app.register_blueprint(proyectos_bp, url_prefix="/proyectos")
    
    app.register_blueprint(estadisticas_bp, url_prefix="/estadisticas")
    app.cli.add_command(seed_datos_iniciales)


    # ---- Registrar comandos CLI ----
    from . import seed
    seed.init_app(app)

    return app
