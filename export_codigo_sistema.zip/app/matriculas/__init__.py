from flask import Blueprint
bp = Blueprint("matriculas", __name__, template_folder="templates")
from . import routes  # noqa
