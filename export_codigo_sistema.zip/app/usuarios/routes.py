from flask import render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from itsdangerous import URLSafeTimedSerializer, SignatureExpired
from ..extensions import db
from .models import Usuario, Role
from .forms import UsuarioForm, RecuperarForm, ResetPasswordForm
from . import bp

# Seguridad: solo admin gestiona
def requiere_admin(f):
    from functools import wraps
    @wraps(f)
    def decorado(*args, **kwargs):
        if not current_user.tiene_rol("administrador"):
            flash("No tienes permisos para realizar esta acción", "error")
            return redirect(url_for("usuarios.index"))
        return f(*args, **kwargs)
    return decorado

@bp.route("/")
@login_required
def index():
    usuarios = Usuario.query.order_by(Usuario.id.desc()).all()
    return render_template("usuarios/index.html", usuarios=usuarios)

@bp.route("/nuevo", methods=["GET", "POST"])
@login_required
@requiere_admin
def nuevo():
    form = UsuarioForm()
    form.roles.choices = [(r.id, r.nombre) for r in Role.query.all()]
    if form.validate_on_submit():
        u = Usuario(
            username=form.username.data,
            email=form.email.data,
            nombre_completo=form.nombre_completo.data,
            activo=form.activo.data
        )
        u.set_password(form.password.data)
        u.roles = Role.query.filter(Role.id.in_(form.roles.data)).all()
        db.session.add(u)
        db.session.commit()
        flash("Usuario creado correctamente", "success")
        return redirect(url_for("usuarios.index"))
    return render_template("usuarios/form.html", form=form, accion="Nuevo")

@bp.route("/editar/<int:id>", methods=["GET", "POST"])
@login_required
@requiere_admin
def editar(id):
    u = Usuario.query.get_or_404(id)
    form = UsuarioForm(obj=u)
    form.roles.choices = [(r.id, r.nombre) for r in Role.query.all()]
    if form.validate_on_submit():
        u.username = form.username.data
        u.email = form.email.data
        u.nombre_completo = form.nombre_completo.data
        if form.password.data:
            u.set_password(form.password.data)
        u.activo = form.activo.data
        u.roles = Role.query.filter(Role.id.in_(form.roles.data)).all()
        db.session.commit()
        flash("Usuario actualizado", "success")
        return redirect(url_for("usuarios.index"))
    form.roles.data = [r.id for r in u.roles]
    return render_template("usuarios/form.html", form=form, accion="Editar")

@bp.route("/bloquear/<int:id>")
@login_required
@requiere_admin
def bloquear(id):
    u = Usuario.query.get_or_404(id)
    u.activo = not u.activo
    db.session.commit()
    flash("Estado del usuario actualizado", "info")
    return redirect(url_for("usuarios.index"))

# Gestión masiva
@bp.route("/accion_masiva", methods=["POST"])
@login_required
@requiere_admin
def accion_masiva():
    ids = request.form.getlist("user_ids")
    accion = request.form.get("accion")
    if not ids:
        flash("Ningún usuario seleccionado", "warning")
        return redirect(url_for("usuarios.index"))
    usuarios = Usuario.query.filter(Usuario.id.in_(ids)).all()
    for u in usuarios:
        if accion == "bloquear": u.activo = False
        elif accion == "activar": u.activo = True
        elif accion == "eliminar": db.session.delete(u)
    db.session.commit()
    flash("Acción masiva completada", "success")
    return redirect(url_for("usuarios.index"))

# Recuperación de contraseña
@bp.route("/recuperar", methods=["GET", "POST"])
def recuperar():
    form = RecuperarForm()
    if form.validate_on_submit():
        user = Usuario.query.filter_by(email=form.email.data).first()
        if not user:
            flash("Correo no encontrado", "error")
        else:
            s = URLSafeTimedSerializer("SECRET")
            token = s.dumps(user.email, salt="reset-pass")
            enlace = url_for("usuarios.reset_password", token=token, _external=True)
            flash(f"Enlace de recuperación: {enlace}", "info")
        return redirect(url_for("auth.login"))
    return render_template("usuarios/recuperar.html", form=form)

@bp.route("/reset/<token>", methods=["GET", "POST"])
def reset_password(token):
    s = URLSafeTimedSerializer("SECRET")
    form = ResetPasswordForm()
    try:
        email = s.loads(token, salt="reset-pass", max_age=3600)
    except SignatureExpired:
        flash("El enlace ha expirado", "error")
        return redirect(url_for("auth.login"))
    user = Usuario.query.filter_by(email=email).first_or_404()
    if form.validate_on_submit():
        user.set_password(form.password.data)
        db.session.commit()
        flash("Contraseña actualizada", "success")
        return redirect(url_for("auth.login"))
    return render_template("usuarios/recuperar.html", form=form, reset=True)

