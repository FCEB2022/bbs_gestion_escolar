from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SelectMultipleField, SubmitField
from wtforms.validators import DataRequired, Email, Length, ValidationError
from ..extensions import db
from .models import Usuario

class UsuarioForm(FlaskForm):
    username = StringField("Usuario", validators=[DataRequired(), Length(min=3, max=80)])
    email = StringField("Correo electrónico", validators=[DataRequired(), Email()])
    nombre_completo = StringField("Nombre completo", validators=[Length(max=150)])
    password = PasswordField("Contraseña", validators=[Length(min=8)])
    roles = SelectMultipleField("Roles", coerce=int)
    activo = BooleanField("Activo")
    submit = SubmitField("Guardar")

    def validate_username(self, field):
        if Usuario.query.filter_by(username=field.data).first():
            raise ValidationError("El nombre de usuario ya existe.")

    def validate_email(self, field):
        if Usuario.query.filter_by(email=field.data).first():
            raise ValidationError("El correo electrónico ya existe.")

class RecuperarForm(FlaskForm):
    email = StringField("Correo registrado", validators=[DataRequired(), Email()])
    submit = SubmitField("Enviar enlace")

class ResetPasswordForm(FlaskForm):
    password = PasswordField("Nueva contraseña", validators=[DataRequired(), Length(min=8)])
    submit = SubmitField("Actualizar contraseña")
