import click
from datetime import datetime
from flask.cli import with_appcontext
from .extensions import db
from .usuarios.models import Usuario, Role
from .models_shared import registrar_actividad


@click.command("seed-datos-iniciales")
@with_appcontext
def seed_datos_iniciales():
    """Inicializa roles base y un usuario administrador por defecto."""
    click.echo("⏳ Creando roles base...")

    roles_base = ["Administrador", "Administrativo", "Supervisor", "Profesor", "Estudiante"]
    roles_creados = []

    for nombre in roles_base:
        rol = Role.query.filter_by(nombre=nombre).first()
        if not rol:
            rol = Role(nombre=nombre, descripcion=f"Rol del sistema: {nombre}")
            db.session.add(rol)
            roles_creados.append(nombre)

    db.session.commit()
    click.echo(f"✅ Roles creados: {', '.join(roles_creados) if roles_creados else 'ya existían.'}")

    # Crear usuario administrador inicial
    admin = Usuario.query.filter_by(username="admin").first()
    if not admin:
        admin = Usuario(
            username="admin",
            email="admin@bbs.edu",
            nombre_completo="Administrador del Sistema",
            activo=True,
            ultimo_login=datetime.utcnow(),
            sesion_activa=False,
        )
        admin.set_password("admin123")
        # asignar rol administrador
        rol_admin = Role.query.filter_by(nombre="Administrador").first()
        if rol_admin:
            admin.roles.append(rol_admin)
        db.session.add(admin)
        db.session.commit()
        registrar_actividad(admin, "Creación automática del usuario administrador")
        click.echo("✅ Usuario administrador creado: admin / admin123")
    else:
        click.echo("ℹ️ El usuario administrador ya existe.")

    click.echo("🎉 Inicialización completa.")
